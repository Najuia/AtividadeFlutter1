import 'package:flutter/material.dart';
import './questionario.dart';

void main() {
  runApp(AulaComponentes());
}

class AulaComponentes extends StatefulWidget {
  @override
  State<AulaComponentes> createState() => _AulaComponentesState();
}

class _AulaComponentesState extends State<AulaComponentes> {
  var perguntaAtual = 0;
  var cor = Colors.white;

  final List<Map<String, Object>> perguntas = [
    {
      "texto": "Qual a sua cor favorita?",
      "respostas": ["Amarelo", "Preto", "Branco", "Azul", "Vermelho"]
    },
    {
      "texto": "Qual é seu animal favorito?",
      "respostas": ["Cachorro", "Gato", "Tartaruga"]
    },
    {
      'pergunta': 'Qual é o seu destino de viagem dos sonhos?',
    'respostas': ['Maldivas', 'Paris', 'Havaí', 'Tóquio'],
    },
    {
      "texto": "Qual seu esporte favorito?",
      "respostas": ["Futebol", "TÊNIS", "Basquete", "Golfe"]
    },
    {
      'pergunta': 'Qual é o seu hobby favorito?',
    'respostas': ['Leitura', 'Pintura', 'Cozinhar', 'Praticar esportes'],
  },
    },
  ];

  void responder() {
    setState(() {
      perguntaAtual++;
    });
  }

  void terminar() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TerminadoScreen()),
    );
  }

  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Jogo das perguntas"),
        ),
        body: perguntaAtual < perguntas.length
            ? Questionario(
                perguntas: perguntas,
                perguntaAtual: perguntaAtual,
                responder: responder,
                terminar: terminar,
              )
            : TerminadoScreen(),
      ),
    );
  }
}
