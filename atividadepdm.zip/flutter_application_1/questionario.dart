import 'package:flutter/material.dart';
import './questao.dart';
import './resposta.dart';

class Questionario extends StatelessWidget {
  final List<Map<String, Object>> perguntas;
  final int perguntaAtual;
  final Function() responder;
  final void Function() terminar;

  Questionario({
    required this.perguntas,
    required this.perguntaAtual,
    required this.responder,
    required this.terminar,
  });

  bool get _isUltimaPergunta {
    return perguntaAtual >= perguntas.length - 1;
  }

  Widget build(BuildContext context) {
    List<Widget> respostas = [];
    for (var resposta in perguntas[perguntaAtual]['respostas'] as List<String>) {
      respostas.add(
        Resposta(resposta, responder),
      );
    }

    return Column(
      children: [
        Questao(perguntas[perguntaAtual]['texto'].toString()),
        ...respostas,
      ],
    );
  }
}

class TerminadoScreen extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Text(
            "Terminado",
            style: TextStyle(fontSize: 28),
            textAlign: TextAlign.left,
          ),
        ],
      ),
    );
  }
}

