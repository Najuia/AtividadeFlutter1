import 'package:flutter/material.dart';

class Resultado extends StatefulWidget {
  final VoidCallback reiniciarQuestionario;

  Resultado(this.reiniciarQuestionario);


  State<Resultado> createState() => _ResultadoState();
}

class _ResultadoState extends State<Resultado> {
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(10),
      child: Column(
        children: [
          const Text(
            'Parabéns! Questionário completo!',
            style: TextStyle(fontSize: 18),
          ),
          ElevatedButton(
            onPressed: widget.reiniciarQuestionario,
            child: const Text('Reiniciar'),
          ),
        ],
      ),
    );
  }
}
