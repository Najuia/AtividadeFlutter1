import 'package:flutter/material.dart';

Future<void> main() async => runApp(QuestionarioApp());

class QuestionarioApp extends StatelessWidget {
  
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Questionário'),
        ),
        body: Questionario(),
      ),
    );
  }
}

class Questionario extends StatefulWidget {
  
  _QuestionarioState createState() => _QuestionarioState();
}

class _QuestionarioState extends State<Questionario> {
  int _indiceQuestao = 0;

  final List<String> _perguntas = [
    'Qual esporte voce gosta?',
    'Qual bochinho voce acha mais fofo?',
    'Qual a capital do Brasil?'
  ];

  List<List<String>> _respostas = [
    ['Volei', 'Futebol', 'Tenis', 'Basquete', 'Ping-pong'],
    ['Gato', 'Cachorro', 'Coelho', 'Peixe', 'Tartaruga'],
    ['Minas Gerais', 'Brasília', 'Rio de Janeiro', 'São Paulo']
  ];

  void _responder() {
    setState(() {
      _indiceQuestao++;
    });
  }

  
  Widget build(BuildContext context) {
    return Column(
      children: [
        Questao(_perguntas[_indiceQuestao]),
        ..._respostas[_indiceQuestao].map((resposta) {
          return Resposta(resposta, _responder);
        }).toList(),
      ],
    );
  }
}

class Questao extends StatelessWidget {
  final String pergunta;

  Questao(this.pergunta);

  
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Text(
        pergunta,
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}

class Resposta extends StatelessWidget {
  final String texto;
  final VoidCallback onSelect;

  Resposta(this.texto, this.onSelect);

  
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      child: ElevatedButton(
        onPressed: onSelect,
        child: Text(texto),
      ),
    );
  }
}