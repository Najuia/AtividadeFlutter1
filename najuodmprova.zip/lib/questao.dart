import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class Questao extends StatelessWidget {
  final String pergunta;
  final double fontSize;
  final Color corTexto;
  final EdgeInsets margin;

  Questao(
    this.pergunta, {
    this.fontSize = 18.0,
    this.corTexto = Colors.black,
    this.margin = const EdgeInsets.all(10),
  }) {
    // TODO: implement Questao
    throw UnimplementedError();
  }

  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: Text(
        pergunta,
        style: TextStyle(fontSize: fontSize, color: corTexto),
      ),
    );
  }
  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(ColorProperty('corTexto', corTexto));
    properties.add(DiagnosticsProperty<EdgeInsets>('margin', margin));
    properties.add(StringProperty('pergunta', pergunta));
  }
}
