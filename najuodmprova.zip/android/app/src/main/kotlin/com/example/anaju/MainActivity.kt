package com.example.anaju

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
